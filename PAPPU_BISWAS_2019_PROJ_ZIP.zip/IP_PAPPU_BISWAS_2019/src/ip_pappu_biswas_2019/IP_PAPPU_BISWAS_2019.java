/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ip_pappu_biswas_2019;

/**
 *
 * @author Pappu biswas
 */
public class IP_PAPPU_BISWAS_2019 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        home h = new home();
        //pappu biswas
        h.setVisible(true);
        //PAPPU BISWAS
        // TODO code application logic here
    }
    
}
